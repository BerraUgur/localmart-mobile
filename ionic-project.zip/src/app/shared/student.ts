export interface Student {
  $key:any,
  name: string;
  email: string
  mobileNumber: any;
}
