export class LoginResponse {
    accessToken?: string;
    refreshToken?: string;
    expiration?: Date;
}