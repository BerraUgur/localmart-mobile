import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { AddressService } from 'src/app/shared/services/address.service';
import { AuthService } from 'src/app/shared/services/auth.service';
import { User } from 'src/app/shared/services/comment';
import { Order } from 'src/app/shared/services/order';
import { OrdersService } from 'src/app/shared/services/orders.service';
import { Product } from 'src/app/shared/services/product';
import { ProductService } from 'src/app/shared/services/product.service';

@Component({
  selector: 'app-basket',
  templateUrl: './basket.page.html',
  styleUrls: ['./basket.page.scss'],
})
export class BasketPage implements OnInit {

  productsArr = [
    {
      id: 1,
      name: "iPhone 16 Pro 1TB Akıllı Telefon Natural Titanium MYNX3TU/A",
      description: "iPhone 16 Pro 1TB Akıllı Telefon Natural Titanium MYNX3TU/A",
      district: "Bornova",
      city: "İzmir",
      sellerPhone: "0555 123 4567",
      price: '',
      discountedPrice: 99.999,
      mainImage: "https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MMS_144721927?x=280&y=190&format=jpg&quality=80&sp=yes&strip=yes&trim&ex=280&ey=190&align=center&resizesource&unsharp=1.5x1+0.7+0.02&cox=0&coy=0&cdx=280&cdy=190",
    },
    {
      id: 2,
      name: "GRUNDIG GDH 92 PKS A++ Enerji Sınıfı 9 kg Isı Pompalı Kurutma",
      description: "GRUNDIG GDH 92 PKS A++ Enerji Sınıfı 9 kg Isı Pompalı Kurutma",
      district: "Kadıköy",
      city: "İstanbul",
      sellerPhone: "0533 987 6543",
      price: '',
      discountedPrice: 16.399,
      mainImage: "https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MMS_133515701?x=280&y=190&format=jpg&quality=80&sp=yes&strip=yes&trim&ex=280&ey=190&align=center&resizesource&unsharp=1.5x1+0.7+0.02&cox=0&coy=0&cdx=280&cdy=190",
    },
    {
      id: 3,
      name: "LENOVO Tab 10.1 inç 4/128GB WUXGA Tablet + Kılıf ZAEH0039TR",
      description: "LENOVO Tab 10.1 inç 4/128GB WUXGA Tablet + Kılıf ZAEH0039TR",
      district: "Çankaya",
      city: "Ankara",
      sellerPhone: "0544 765 4321",
      price: '',
      discountedPrice: 5.499,
      mainImage: "https://assets.mmsrg.com/isr/166325/c1/-/ASSET_MMS_149860847?x=280&y=190&format=jpg&quality=80&sp=yes&strip=yes&trim&ex=280&ey=190&align=center&resizesource&unsharp=1.5x1+0.7+0.02&cox=0&coy=0&cdx=280&cdy=190",
    }
  ];

  products:any = []

  currentBasket:any = [];

  currentUserId?: number;
  currentUser?: User;

  city:any = '';
  district:any = '';
  postalCode:any = '';
  openAddress:any = '';
  note:any = '';
  
  constructor(
    private alertController: AlertController,
    private router: Router,
    private productService: ProductService,
    private addressService: AddressService,
    private ordersService: OrdersService,
    private authService: AuthService
  ) {}
  
  ngOnInit() {
    if (localStorage.getItem('basket')) {
      this.currentBasket = JSON.parse((<any>localStorage.getItem('basket')));
    }

    if (this.currentBasket) {
      this.currentBasket.forEach((product:any) => {
        this.productService.getProductById(product.productId).subscribe((product: Product | null) => {
            if (product) {              
              this.authService.getUser(product.sellerUserId).subscribe((user) => {
                product.sellerPhone = user.phoneNumber;
                this.products.push(product);
                // this.updateTotalPrice()
              })

            } else {
              console.error('Product not found');
            }
          },
          error => {
            console.error('Error fetching product details', error);
          }
        );
      });

      this.currentUserId = this.authService.getCurrentUserId();
      this.authService.getUser(this.currentUserId).subscribe((user) => {
        this.currentUser = user
        console.log(this.currentUser)
      });

      // this.currentBasket.forEach((basketItem: any) => {
      //   let matchedProduct:any = this.productsArr.find(p => p.id === basketItem.productId);
      //   if (matchedProduct) {
      //     this.products.push(matchedProduct);
      //   }
      // });
    }

  }


  get totalPrice() {
    return this.products.reduce((sum, product) => sum + product.discountedPrice, 0).toFixed(2);
  }

  async deleteProductBasket(productId: number) {
    const alert = await this.alertController.create({
      header: 'Emin misiniz?',
      message: 'Bu ürünü sepetinizden silmek istiyor musunuz?',
      buttons: [
        {
          text: 'İptal',
          role: 'cancel'
        },
        {
          text: 'Evet',
          handler: () => {
            this.products = this.products.filter((p: any) => p.id != productId);
  
            let newBasket: any = [];
            this.products.forEach(p => {
              newBasket.push({ productId: p.id, quantity: 1 });
            });
  
            this.currentBasket = newBasket;
            localStorage.setItem('basket', JSON.stringify(newBasket));
  
            // Silme işlemi başarılı bildirimi
            this.alertController.create({
              header: 'Başarılı!',
              message: 'Ürün sepetinizden silindi.',
              buttons: ['Tamam']
            }).then(successAlert => successAlert.present());
          }
        }
      ]
    });
  
    await alert.present();
  }

  approveBasket(){
    if(this.city == '' || this.district == '' || this.postalCode == '' || this.openAddress == ''){
      this.alertController.create({
        header: 'Eksik Bilgi!',
        message: 'Lütfen Adres Bilgilerini Doldurunuz.',
        buttons: ['Tamam']
      }).then(errorAlert => errorAlert.present());
      return
    }else{
      const addressRequest: any = {
        city: this.city,
        userId: this.currentUserId,
        district: this.district,
        postalCode: this.postalCode,
        openAddress: this.openAddress,
        // user: null
      };
      console.log('Address request', addressRequest);
      this.addressService.addAddress(addressRequest).subscribe(
        data => {
          let order: Order = {
            userId: this.currentUserId,
            addressId: data.id,
            note: this.note,
            orderItems: this.currentBasket
          }
          this.ordersService.addOrder(order).subscribe(data => {
            this.alertController.create({
              header: 'Başarılı!',
              message: 'Siparişiniz Onaylanmıştır.',
              buttons: ['Tamam']
            }).then(successAlert => successAlert.present());
            console.log(data)
            this.currentBasket = [];
            localStorage.removeItem('basket');
            
            this.router.navigate(['/my-orders/'])
          })
        },
        error => {
          console.error('Address save failed', error);
        }
      );
    }
  }


}
